import SwiftUI
import Guide

@main
struct MyApp: App {
    @StateObject var notesModel = NotesModel()
    
    var body: some Scene {
        WindowGroup {
            HomeView()
                .environmentObject(notesModel)
        }
    }
}
